
let handler = async (m, { conn }) => {

m.reply(`
≡  *${NSnama}ᴮᴼᵀ ┃ SUPPORT*

◈ ━━━━━━━━━━━━━━━━━━━━ ◈
▢ Grupo *1*
https://nansoffc.my.id

▢ Grupo *2*
https://nansoffc.my.id

▢ Grupo *NSFW* 🔞
https://nansoffc.my.id

▢ 𝐌𝐘 - 𝐌𝐚𝐲𝐥𝐮𝐱 | ᴮᴼᵀ⚡
https://nansoffc.my.id

▢ 📲💻ANDROID WORLD🎬🎮
https://nansoffc.my.id

◈ ━━━━━━━━━━━━━━━━━━━━ ◈
▢ Todos los Grupos
 https://instabio.cc/nansoffcf

▢ *Telegram*
• https://t.me/nansoffc
 ▢ *PayPal*
• https://nansoffc.my.id
▢ *YouTube*
• https://www.youtube.com/nansoffc`)

}
handler.help = ['support']
handler.tags = ['main']
handler.command = ['grupos', 'groups', 'support'] 

export default handler
